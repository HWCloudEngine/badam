=========
Copyright
=========

.. include:: ../../COPYRIGHT
