__author__ = 'wangfeng'
"""
:mod:`aws` -- Hybrid cloud support for Amazon Web Service using libclou sdk.
"""

from nova.virt.aws import driver

#VCloudDriver = driver.VCloudDriver
AwsEc2Driver = driver.AwsEc2Driver
